const itens = document.querySelectorAll(".cardapio-item");
const listas = document.querySelectorAll(".cardapio-lista");

const abrirLista = (evento) => {
  const id = evento.target.id
  if (listas[id].style.display == 'flex') {
    listas[id].style.display = 'none'
  }
  else {
    listas[id].style.display = 'flex'
  }
};

itens.forEach((itens) =>
  itens.addEventListener('click', abrirLista)
);